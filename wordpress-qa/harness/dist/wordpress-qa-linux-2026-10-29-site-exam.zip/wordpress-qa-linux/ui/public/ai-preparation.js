export function initAiPreparation({container,api,readConfig,applyConfig,openCheck}){
  const panel=document.createElement('section');panel.className='ai-preparation';
  panel.innerHTML='<h3>AIで検査の不足を補う</h3><p>登録前でも利用できます。AIは候補と確認事項を提案します。読み取り検査だけを選んで追加でき、送信・注文の許可は変更しません。最後に設定の「保存」が必要です。</p><label>合意済みの読込時間の上限（ミリ秒・任意）<input data-budget type="number" min="100" max="120000" placeholder="例：3000"></label><p>基準が決まっていない場合は空欄にしてください。AIに勝手な基準を設定させません。</p><button type="button" data-propose>AIで不足ケース・準備事項を確認</button><p data-status role="status"></p><div data-output></div><button type="button" data-apply hidden>選んだ検査を設定に反映</button>';
  container.append(panel);const q=s=>panel.querySelector(s);let pending=null,busy=false,generation=0;
  function reset(){generation++;pending=null;q('[data-output]').replaceChildren();q('[data-status]').textContent='';q('[data-apply]').hidden=true;}
  q('[data-propose]').onclick=async()=>{if(busy)return;reset();const ticket=generation;busy=true;q('[data-propose]').disabled=true;q('[data-status]').textContent='検査の構造情報から提案を作っています…';try{
    const config=readConfig(),answers=q('[data-budget]').value?{maxLoadMs:Number(q('[data-budget]').value)}:{};
    const result=await api('/api/ai/propose',{method:'POST',body:JSON.stringify({config,answers})});
    if(ticket!==generation)return;pending=result;
    pending.proposal.cases.forEach((c,i)=>{const label=document.createElement('label'),check=document.createElement('input');check.type='checkbox';check.dataset.choice=i;label.append(check,document.createTextNode(`${config.pages[c.pageIndex].path}：${{layout:'横はみ出し',performance:'読込時間',canonical:'正規URL'}[c.kind]} ／ ${c.viewport==='mobile'?'スマホ':'PC'} — ${c.reason}`));q('[data-output]').append(label);});
    pending.proposal.questions.forEach(question=>{const box=document.createElement('div'),p=document.createElement('p');p.textContent=`${config.checks[question.checkIndex].title??config.checks[question.checkIndex].id}：${question.question}（${question.reason}）`;const b=document.createElement('button');b.type='button';b.textContent='この項目を設定する';b.onclick=()=>openCheck(config.checks[question.checkIndex].id);box.append(p,b);q('[data-output]').append(box);});
    q('[data-apply]').hidden=!pending.proposal.cases.length;q('[data-status]').textContent=`候補${pending.proposal.cases.length}件、確認事項${pending.proposal.questions.length}件。適用しても合否は変わりません。保存後に再検査してください。`;
  }catch(e){q('[data-status]').textContent=e.message;}finally{busy=false;q('[data-propose]').disabled=false;}};
  q('[data-apply]').onclick=async()=>{if(!pending||busy)return;const ticket=generation;busy=true;try{const result=await api('/api/ai/apply',{method:'POST',body:JSON.stringify({id:pending.id,config:readConfig(),indices:[...q('[data-output]').querySelectorAll('[data-choice]:checked')].map(e=>Number(e.dataset.choice))})});if(ticket!==generation)return;applyConfig(result.config);pending=null;q('[data-apply]').hidden=true;q('[data-status]').textContent='入力中の設定に反映しました。最後に「保存」を押してください。'+result.notes.join(' ');}catch(e){q('[data-status]').textContent=e.message;}finally{busy=false;}};
  return {reset};
}
