const e=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function initSiteExam({state,api}){
 const panel=document.createElement('section');panel.id='site-exam';panel.className='panel exam-panel';document.querySelector('.workspace-grid').before(panel);
 let scope='',data=null,busy=false,dirty=false,ticket=0,suggestions=[];
 const endpoint=()=>`/api/projects/${encodeURIComponent(state.projectId)}/runs/${encodeURIComponent(state.runId)}`;
 const message=t=>{const el=panel.querySelector('[data-message]');if(el)el.textContent=t;};
 const value=i=>i.certainty==='pending'||!i.scores?null:i.scores.reduce((a,b)=>a*b,1);
 const label=i=>{const v=value(i);return v===null?'採点保留':`${v} / 100 ・ ${v>=80?'重大':v>=50?'高':v>=20?'中':'低'}（${i.certainty==='confirmed'?'確定':'暫定'}）`;};
 function summary(){if(!data)return;const values=data.issues.map(value).filter(v=>v!==null);panel.querySelector('[data-summary]').textContent=`検出課題の最高危険度：${values.length?Math.max(...values)+' / 100':data.issues.length?'採点保留':'採点対象なし'} ／ 課題${data.issues.length}件・採点保留${data.issues.filter(i=>value(i)===null).length}件・内容確認${data.issues.filter(i=>i.reviewed).length}件。判定済み${data.coverage.executed} / ${data.coverage.total}項目、未確認${data.coverage.unconfirmed.length}項目。`;}
 function showSuggestions(){
    panel.querySelector('[data-suggestions]').innerHTML=`<h3>AIの説明候補（未反映）</h3>${suggestions.map((s,n)=>`<div class="exam-ai"><h4>${e(data.issues.find(i=>i.id===s.id)?.title)}</h4><p>${e(s.impact)}</p><p>${e(s.action)}</p><button type="button" data-apply-ai="${n}">この説明を入力欄に反映</button></div>`).join('')}`;
 }
 function draw(){
  if(!data)return;
  panel.innerHTML=`<div class="panel-heading"><h2>診断評価・顧客向け報告書</h2></div><p data-summary></p><p class="quiet">点数は検出課題の危険度であり、サイト全体の安全性を表しません。未確認や採点保留を0点として扱いません。保存済みの証拠から説明を整理します。</p><details><summary>採点基準</summary><p>影響1～5 × 起こりやすさ1～5 × 影響範囲1～4。80以上：重大、50以上：高、20以上：中、19以下：低。独自基準でありCVSSではありません。影響は軽微な表示から機能停止・情報漏えいまで、起こりやすさは必要条件と再現性、範囲は対象ページ・利用者から判断します。</p><p>アクセシビリティの基準不足にはルールに基づく暫定点を表示します。それ以外は、証拠を確認して採点してください。複数ケースをまとめた単位は同じ症状であり、同じ原因と断定しません。</p></details><div class="exam-actions"><button type="button" data-save>評価を保存</button><button type="button" data-ai>Claudeで説明候補を補完</button><button type="button" data-preview>顧客向けHTMLを確認</button><a data-download href="${endpoint()}/customer-report?download=1" download>HTMLをダウンロード</a><button type="button" data-reload>評価を再取得</button></div><p class="quiet">AIには課題の種類とケース数だけを送ります（1回最大40課題）。URL・証拠・本文・認証情報は送りません。候補は一般的な説明で、具体的な原因や対応箇所の確定には証拠の確認が必要です。API利用料が発生します。</p><p data-message role="status">${data.stale?'元の検査結果が更新されたため、以前の採点は適用していません。':data.savedAt?'評価を保存済みです。':'評価はまだ保存していません。未確認の説明を出力すると下書きになります。'}</p><div data-suggestions></div><div class="exam-issues">${data.issues.map((i,n)=>`<details class="exam-issue" data-issue="${n}"><summary><span>${e(i.title)}</span> <strong data-score="${n}">${e(label(i))}</strong> <small>${i.cases.length}ケース</small></summary><p>${e(i.impact)}</p><label>採点の状態<select data-field="certainty"><option value="pending" ${i.certainty==='pending'?'selected':''}>採点保留</option><option value="provisional" ${i.certainty==='provisional'?'selected':''}>暫定</option><option value="confirmed" ${i.certainty==='confirmed'?'selected':''}>確定</option></select></label><div class="exam-score-fields">${['影響の大きさ','起こりやすさ','影響範囲'].map((name,j)=>`<div><label>${name}<select data-score-input="${j}"><option value="">未設定</option>${Array.from({length:j===2?4:5},(_,k)=>`<option value="${k+1}" ${i.scores?.[j]===k+1?'selected':''}>${k+1}</option>`).join('')}</select></label><label>採点理由<textarea data-reason="${j}" maxlength="3000">${e(i.reasons[j])}</textarea></label></div>`).join('')}</div><label>利用者への影響<textarea data-field="impact" maxlength="3000">${e(i.impact)}</textarea></label><label>対応方法（管理画面で可能な方法を優先）<textarea data-field="action" maxlength="3000">${e(i.action)}</textarea></label><label><input type="checkbox" data-field="reviewed" ${i.reviewed?'checked':''}>証拠・採点理由・説明内容を確認した</label><details><summary>根拠となる検査・証拠</summary>${i.cases.map(c=>`<div><strong>${e(c.title??c.id)}</strong><p>${e(c.id)}</p>${c.evidence.map(f=>`<a href="${endpoint()}/files?path=${encodeURIComponent(f)}" data-evidence>${e(f)}</a>`).join(' ／ ')||'<p>証拠ファイルなし。追加確認が必要です。</p>'}</div>`).join('')}</details></details>`).join('')||'<p>判定できた範囲では、不合格を検出しませんでした。未確認の範囲も確認してください。</p>'}</div><details><summary>未確認の項目（${data.coverage.unconfirmed.length}件）</summary><ul>${data.coverage.unconfirmed.map(r=>`<li>${e(r.title??r.id)}：${e(({blocked:'実行不能',review:'確認待ち',not_run:'未実施',preparation:'準備待ち'})[r.status]??'未確認')}</li>`).join('')}</ul></details><div data-frame hidden><div class="exam-actions"><button type="button" data-close-frame>表示を閉じる</button></div><iframe title="報告書・証拠のプレビュー" sandbox></iframe></div>`;summary();
 }
 async function load(){const current=++ticket,url=endpoint();busy=true;try{const result=await api(url+'/exam');if(current!==ticket)return;data=result;dirty=false;suggestions=[];draw();}catch(err){if(current===ticket)panel.innerHTML=`<h2>診断評価</h2><p>${e(err.message)}</p><button type="button" data-reload>再取得</button>`;}finally{if(current===ticket)busy=false;}}
 function changed(){dirty=true;panel.querySelector('[data-frame]').hidden=true;message('未保存の変更があります。説明・採点を変更した課題は内容確認を解除しました。');summary();}
 panel.addEventListener('change',event=>{
  const box=event.target.closest('[data-issue]');if(!box)return;const n=Number(box.dataset.issue),i=data.issues[n],field=event.target.dataset.field;
  i.certainty=box.querySelector('[data-field=certainty]').value;const scores=[...box.querySelectorAll('[data-score-input]')].map(x=>x.value?Number(x.value):null);i.scores=scores.every(v=>v!==null)?scores:null;
  i.reasons=[...box.querySelectorAll('[data-reason]')].map(x=>x.value);i.impact=box.querySelector('[data-field=impact]').value;i.action=box.querySelector('[data-field=action]').value;
  i.reviewed=field==='reviewed'?event.target.checked:false;if(field!=='reviewed'){box.querySelector('[data-field=reviewed]').checked=false;i.source='manual';}
  box.querySelector('[data-score]').textContent=label(i);changed();
 });
 panel.addEventListener('input',event=>{if(event.target.matches('textarea'))event.target.dispatchEvent(new Event('change',{bubbles:true}));});
 panel.addEventListener('click',async event=>{
  const target=event.target.closest('button,a');if(!target)return;
  if(target.hasAttribute('data-close-frame')){panel.querySelector('[data-frame]').hidden=true;return;}
  if(target.hasAttribute('data-evidence')){event.preventDefault();const frame=panel.querySelector('[data-frame]');frame.hidden=false;frame.querySelector('iframe').src=target.href;frame.scrollIntoView({block:'nearest'});return;}
  if(target.hasAttribute('data-download')||target.hasAttribute('data-preview')){
   if(dirty){event.preventDefault();message('変更した評価を保存してからHTMLを出力してください。');return;}
   if(target.hasAttribute('data-preview')){const frame=panel.querySelector('[data-frame]');frame.hidden=false;frame.querySelector('iframe').src=endpoint()+'/customer-report';frame.scrollIntoView({block:'nearest'});}return;
  }
  if(target.hasAttribute('data-reload')){if(dirty&&!confirm('未保存の変更を破棄して再取得しますか？'))return;await load();return;}
  if(target.hasAttribute('data-apply-ai')){
   const suggestion=suggestions[Number(target.dataset.applyAi)],i=data.issues.find(i=>i.id===suggestion?.id);if(!i)return;i.impact=suggestion.impact;i.action=suggestion.action;i.source='ai';i.reviewed=false;suggestions=suggestions.filter(x=>x.id!==suggestion.id);draw();changed();message('AI候補を入力欄へ反映しました。証拠を確認してから保存してください。点数は変更していません。');return;
  }
  if(busy||!data)return;const current=ticket,url=endpoint();busy=true;for(const el of panel.querySelectorAll('input,textarea,select,button'))el.disabled=true;
  try{
   if(target.hasAttribute('data-save')){
    const items=data.issues.map(({id,scores,certainty,reasons,impact,action,reviewed,source})=>({id,scores,certainty,reasons,impact,action,reviewed,source}));
    const result=await api(url+'/exam',{method:'POST',body:JSON.stringify({version:data.version,fingerprint:data.fingerprint,items})});if(current!==ticket)return;data=result;dirty=false;draw();message('評価を保存しました。検査の合否と証拠は変更していません。');
   }else if(target.hasAttribute('data-ai')){
    message('Claudeで説明候補を生成しています…');const result=await api(url+'/exam-ai',{method:'POST',body:JSON.stringify({version:data.version,fingerprint:data.fingerprint})});if(current!==ticket)return;suggestions=result.suggestions;
    showSuggestions();message('候補はまだ保存・反映していません。点数はAIに決めさせません。');
   }
  }catch(err){if(current===ticket)message(err.message);}finally{if(current===ticket){busy=false;for(const el of panel.querySelectorAll('input,textarea,select,button'))el.disabled=false;}}
 });
 function render(){const r=state.report?.report,key=r&&r.runStatus==='finished'?`${state.projectId}/${state.runId}`:'';panel.hidden=!key;if(key===scope)return;scope=key;ticket++;data=null;dirty=false;busy=false;suggestions=[];if(key){panel.innerHTML='<h2>診断評価</h2><p>保存済みの検査結果を読み込んでいます…</p>';void load();}}
 return {render};
}
